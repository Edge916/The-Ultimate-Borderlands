Ultimate Vault Hunters v0.2.4 - OVERCLOCK UPGRADE OBSERVERS.

NEXT TEST: record the game's normal upgrade check and point cost while you
highlight skills. Overclock stays INACTIVE. Do not buy any skill.

INSTALL:
Close BL2. Use a backed-up Gaige save alone with network setting Offline.
Replace only sdk_mods/UltimateVaultHunterDeathtrapBoost with this ZIP's folder.
Keep one project mod and all PythonSDK/core mods. Start a fresh BL2 process.
The folder directly contains __init__.py, pyproject.toml and this README.

ONE TEST:
1. At main menu confirm MODS title:
   UVH v0.2.4 - OVERCLOCK UPGRADE OBSERVERS
   Press 1 - ARM ONE GAIGE INIT NODE TEST before Continue.
2. Continue as Gaige. In MODS press 5 - START UPGRADE OBSERVERS.
3. Open Skills. Hover/highlight Deathtrap Overclock, More Pep and Myelin.
   Also use arrow keys/controller navigation to highlight each if available.
   Spend about 5 seconds on each; finish promptly within 90 seconds.
   DO NOT press the purchase/upgrade control or spend any points.
4. Return to MODS: 6 - STOP / REPORT UPGRADE OBSERVERS.
5. Press 3 - CANCEL / RESTORE NATIVE ARRAYS, then exit BL2.
6. Tell Codex "done". Leave BL2 closed until its log is preserved; a relaunch
   may overwrite it. Restart before normal play to discard the prototype cache.

Do not buy, respec, travel, enable co-op or use legacy/manual boost buttons in
this run. An abort/empty capture is useful evidence: stop/restore/exit and share
the log. Do not attempt a purchase to force a query. Button 4 remains available
for read-only metadata inspection but is unnecessary for this test.

WHAT BUTTONS 5/6 DO:
Two explicitly started POST observers of normal CanUpgradeSkill and
GetSkillUpgradeCost calls. No hooks/game access on import. They never call or
override those functions, edit arguments/returns, load packages, change points,
grades, definitions, durations or saves. They recheck the current owned Gaige
tree, exact inert native patch/originals/runtime registration, solo role and
both one-player rosters. Known PRI points, grades and indices must stay unchanged.
Candidate rank must remain zero. Unknown/changed state ends observation.

The UI must be SkillTreeGFxObject with WPCOwner==pc; CurrentSkill identifies
the eligibility query. Mouse CurrentSkill_Rollover is logged separately, never
used as a substitute. Cost calls require the owned controller and args.Skill.
Only Overclock, MorePep and Myelin are captured. Actual POST returns are logged:
ESkillTreeFailureReason name/value for eligibility (NOT Boolean), and a verified
nonnegative int for cost. Unknown types abort. Loaded function metadata must
match the two descriptors observed in v0.2.3 before hooks are installed.

Limits: 24 captures, 2048 callback attempts, two copies of each result.
90-second expiry is checked on the NEXT observed call, with no background timer.
Always press STOP. STOP/CANCEL/disable/error/state change/limits remove observers;
failed removals leave capture inert and retain only our hooks for retry.

EXPECTED LOG:
[UVH-INITNODE] PRE INSERT VERIFIED; one runtime node, both originals,
Observers remaining=0 after initialization.
[UVH-UPGRADE] START v0.2.4 POST observers=2 with baseline points/ranks;
RESULT lines with skill and actual return; FINAL unchanged_from_start=True;
STOP remaining=0; six SUMMARY lines ([] means NOT OBSERVED).
[UVH-NEWNODE] RESTORE result=True; MorePep/Myelin and True/False/True restored.
Missing calls are not failed upgrades. Observed checks do not prove purchases,
refunds, persistence or the node's effect. Report errors rather than guessing.

ROLLBACK:
Button 3 disarms/removes observers, then restores native arrays if they still
match our writes. Failed restores retain the snapshot; independent changes are
not overwritten. Disable attempts the same cleanup. Restoration does not reset
the engine-built player/UI cache, refund points, change ranks or restore saves.
Restart after EVERY node test. If rollback fails, exit without saving/restart.

VERIFIED VS PENDING:
v0.2.1 is user-confirmed visible. v0.2.2/v0.2.3 live read-only diagnostics
kept sampled points/ranks unchanged and restored arrays with zero observers.
All three tested versioned ZIPs remain unchanged. The separate manual duration
prototype (60 -> 75 seconds) remains independently verified and unchanged.
v0.2.4 passed 57 mock tests, syntax compilation and isolated three-file ZIP
checks. Its observers have NO real-game result yet; UI fields/return wrappers
and natural query timing require this test. No purchase/persistence/node effect
is verified. Of 48 v0.2.1 functions, only cancellation adds observer cleanup;
insertion, solo guard, rollback and manual duration bodies remain unchanged.
