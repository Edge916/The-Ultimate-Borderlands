Ultimate Vault Hunters v0.2.5 - OVERCLOCK UI NAVIGATION TRACE.

NEXT TEST: record normal UI navigation/refresh and owned selected/hovered skills.
Overclock is still INACTIVE. DO NOT BUY ANY SKILL.

v0.2.4's setup/stop/restoration passed, but neither upgrade observer received a
call despite all three skills being highlighted. This is a different trace.
v0.2.5 passed 71 mocks and package checks; no real-game result yet.

INSTALL:
Close BL2. Replace only sdk_mods/UltimateVaultHunterDeathtrapBoost with this ZIP's
folder; keep one project mod and all PythonSDK/core mods. Use your backed-up
Gaige save alone with network setting Offline. Start a fresh BL2 process.

ONE TEST:
1. At MAIN MENU, before loading Gaige, confirm MODS title:
   UVH v0.2.5 - OVERCLOCK UI NAVIGATION TRACE
   Press 1 - ARM ONE GAIGE INIT NODE TEST, then Continue.
   ARM after Continue will refuse; it must run before the tree initializes.
2. Once Gaige is loaded, press 7 - START UI NAVIGATION TRACE.
3. Open Skills. Hover/highlight Deathtrap Overclock, More Pep and Myelin,
   about five seconds each. Also use arrow keys/controller navigation if
   available. DO NOT press the purchase/upgrade control, left-click to buy
   or right-click a skill. Finish promptly within 90 seconds.
4. Press 8 - STOP / REPORT UI TRACE + SNAPSHOT.
5. Press 3 - CANCEL / RESTORE NATIVE ARRAYS, then fully exit BL2.
6. Tell Codex "done" and leave BL2 closed until its final log is preserved.
   Restart before normal play to discard the engine-built prototype cache.

Use only 1,7,8,3 in this run. Do not use 5/6, legacy insertion, the old loading
trace, respec, travel, co-op or the manual boost. If anything aborts, stop,
cancel, exit and share the log. Do not spend points to force a query.

WHAT THE TRACE DOES:
Explicitly discovers loaded SkillTreeGFxObject navigation/refresh functions
from canonical metadata; no guessed undiscovered hook paths. It prefers the
Init/extInitTree calls previously observed when opening Skills, then navigation,
input and info updates. Logs up to 24 candidate paths/8 raw fields per function.
Up to 10 functions/20 PRE and POST_UNCONDITIONAL observers. POST_ANY in the
log may include a call blocked by another mod, not proof it executed.

Every callback rechecks the same Gaige/controller/pawn/world/PRI/tree, both
one-player rosters, exact inert native patch/runtime registration and unchanged
known points/ranks/indices. Candidate rank stays zero. UI selection is read only
from an exact SkillTreeGFxObject with WPCOwner==pc. CurrentSkill and
CurrentSkill_Rollover remain distinct; definitions must have a unique owned
runtime entry/index. Unknown values are labelled unavailable/unverified.
NumSkillPoints and target tier bUnlocked are direct reads, not eligibility.

START/STOP scan up to 32 UI instances and print up to four owned selections.
No UI at START is allowed: opening Skills may create it. STOP selection may
differ after closing Skills. No UI state is forced and no args/ret are read.
Observers never invoke native functions, override/block calls, change points,
grades, definitions, durations or saves, or load packages. Import is inert.

Limits: 48 events, 2048 callback attempts, two copies of each state.
90 seconds checked on the NEXT observed call, without a background timer.
Always press STOP. Stop/cancel/disable/error/state change/limits clear capture
and remove owned hooks; failed removals leave them inert and retained for retry.

EXPECTED LOG:
[UVH-INITNODE] PRE INSERT VERIFIED, one runtime node, both originals,
Observers remaining=0 after initialization.
[UVH-UI] DISCOVERY/CANDIDATE/METADATA; START v0.2.5; owned SNAPSHOT/INVENTORY;
EVENT PRE/POST_ANY with current/rollover/UI points/tier unlock;
FINAL points/ranks unchanged_from_start=True; STOP remaining=0.
[UVH-NEWNODE] RESTORE result=True: MorePep/Myelin and True/False/True.
Empty calls/snapshots do not establish purchase failure. Report the log.

ROLLBACK:
Button 3 removes UI/upgrade/init observers and restores only owned native
array writes that still match. Independent changes are not overwritten; failed
restores retain snapshots. Disable attempts the same cleanup. This cannot
clear the engine-built cache, refund points, restore ranks or undo a save.
Restart after EVERY node test. If restoration fails, exit without saving/restart.

PRESERVED:
All four tested versioned ZIPs are unchanged. v0.2.1 confirmed visibility;
v0.2.2/v0.2.3 diagnostics/restoration passed; v0.2.4 setup/cleanup passed with
zero query callbacks. v0.2.5 has 71 mocked tests and exact three-file package
verification, but no engine result yet. Native insertion/rollback/solo guards
and the independently verified manual Deathtrap 60 -> 75-second prototype
remain unchanged. The new node does not apply that effect. Purchase, refund,
persistence and the node's automatic duration effect remain untested.
