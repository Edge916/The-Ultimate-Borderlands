Ultimate Vault Hunters v0.2.2 - OVERCLOCK PURCHASE DIAGNOSTICS.

v0.2.1 is the first user-confirmed visible native Deathtrap Overclock node.
Its log verified one inert runtime candidate, both original first-tier skills,
grade 0, observer removal and original native-array restoration.

v0.2.2 adds button 4 for READ-ONLY rank/point/tier/definition and purchase-function
metadata inspection. All existing v0.2.1 functions remain unchanged. The node
is still inert; the independently verified manual +15-second button is separate.
No point purchase, persistence or node duration effect has been tested.

INSTALL:
Close BL2. Keep a verified Gaige save backup outside the game's SaveData folder.
Replace only sdk_mods/UltimateVaultHunterDeathtrapBoost with this ZIP's folder.
Keep one project mod; preserve PythonSDK/core mods. Start a fresh BL2 process.

ONE TEST (backed-up Gaige alone, network setting Offline):
1. At main menu before Continue: 1 - ARM ONE GAIGE INIT NODE TEST (SOLO / INERT).
2. Continue as Gaige; press 4 - INSPECT OVERCLOCK PURCHASE DATA (READ ONLY).
3. Open Skills and hover/highlight Deathtrap Overclock. Note its displayed rank,
   any upgrade prompt and any locked requirement. DO NOT BUY ANY SKILL.
4. Return to MODS and press 4 again.
5. Press 3 - CANCEL / RESTORE NATIVE ARRAYS (THEN RESTART), then exit BL2.
6. Tell Codex "done" and the tooltip observations. Leave the game closed until
   the log is copied; a new launch may overwrite it. Restart before normal play
   to ensure the engine-built prototype cache is discarded.

Do not respec, travel, enable co-op, use legacy insertion or the manual boost
during this run. Abort/error is useful evidence: stop, exit and share the log.
Do not force a write, spend points or invoke discovered functions.

Expected [UVH-INITNODE]: ARMED, verified one-player session, PRE INSERT VERIFIED,
RESULT native=True runtime_node_count=1 original_skills_present=True,
Observers remaining=0. Button 2 remains the original read-only insertion check.
Expected [UVH-PURCHASE]: BEGIN v0.2.2 snapshot, point fields, NODE rank=0
max_rank=1, definition comparisons, DISCOVERED paths and FUNCTION/FIELD metadata.
Unknown fields/metadata errors are logged, never guessed. No fields are repaired.
Metadata alone does not prove a callable signature, actual cost or eligibility.

Button 4 requires the current recorded Gaige tree and solo roster to match,
the native patch and both originals to remain, and the candidate's runtime
owner/index/first tier to verify. It reads points, ranks, tier state, grade rules,
skill type/class and effect/action counts. The SDK's _properties() reflection
iterator reads descriptors; it does not execute the game function. Scans/output
are capped at 30000 function objects, 32 paths, 12 detailed functions, 16 fields
per function. It installs no observers, calls no native gameplay functions,
loads no packages, writes no points/grades/definitions/durations/saves.

ARM retains the v0.2.1 explicitly armed one-shot PRE insertion at the observed
PlayerSkillTree.Initialize call. No hooks or mutations start on import. Its solo
gate accepts SDK Standalone/ListenServer only with one owned local player and
one owned PRI roster entry. It guards exact Gaige/tree/branch/layout identity,
empty initialization state, six tiers and pristine original first-row arrays.
A separate grade-0, rank-1 SkillDefinition with empty effects/actions is created.
Native initialization runs normally; the mod never edits cache indices.

ROLLBACK:
Button 3 disarms/removes observers and restores native arrays only if they still
match the mod's last writes. Failed restores keep the snapshot; independent
changes are not overwritten. Disabling the mod attempts the same cleanup.
Expected RESTORE result=True: skills MorePep/Myelin, occupancy True/False/True.
Restore does not rewrite the engine-built cache and cannot refund a point,
restore a grade or undo a saved purchase. If restoration fails, exit without
saving and restart. Never buy the test node or restore saves automatically.

Diagnostic loading snapshots/trace, legacy insertion and manual duration buttons
remain available. Use only buttons 1, 4 and 3 for this test. The established
manual Deathtrap boost remains unchanged and independently game-verified.
This diagnostic version passed 37 local simulated tests and packaging checks;
its new button has no real-engine result yet. The tested v0.2.1 versioned ZIP is
preserved unchanged as the visible-node baseline.
