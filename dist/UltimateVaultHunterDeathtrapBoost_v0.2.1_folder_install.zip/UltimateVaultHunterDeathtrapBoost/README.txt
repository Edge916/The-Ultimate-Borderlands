Ultimate Vault Hunters v0.2.1 - PRE-INITIALIZE INERT NODE TEST.

Real v0.1.7 log: three main-menu attempts aborted before insertion because
the branch/layout could not be accessed. No node was created in those attempts.
Real v0.1.8 log: streaming tree/branches were briefly accessible at main menu,
then missing two seconds later. In Gaige's map, branches/layout were present and
the controller referenced PlayerSkillTree_0; the streaming definition was missing.
The trace discovered zero candidates and registered no observers.

Real v0.1.9 log: the corrected trace registered 16 observers, captured 20 events,
and removed them all. PlayerSkillTree.Initialize was observed with Gaige's assets
available, SkillTreeDef pointing to the exact Mechromancer definition, no pawn,
and empty Branches before the call; four branches existed afterward. The Skills
UI later called InitializeGFxHelper and SkillTreeGFxObject.extInitTree.

Real v0.2.0 log: PRE ran, but NetMode=2 triggered the numeric-only solo guard.
The test aborted before constructing/inserting anything and removed all observers.
The user saw no node. This run did not test cache or UI insertion.

v0.2.1 replaces that guard with SDK enum metadata and exact local/connected-player
rosters. It inserts an independent inert node immediately BEFORE this native
initialization, but only if explicitly armed at main menu. It is a VISIBILITY
EXPERIMENT, locally tested only. Do not buy it. The manual +15s boost is separate.

INSTALL:
1. Close BL2. Back up Gaige's save OUTSIDE the game's SaveData directory.
2. Replace the existing sdk_mods/UltimateVaultHunterDeathtrapBoost folder with
   this folder. Keep only one project mod and restart BL2.

NEXT TEST (solo Gaige, backed-up save; do not spend points):
1. Set BL2's network setting to Offline. At MAIN MENU, before Continue, open MODS
   and select "UVH v0.2.1 - DEATHTRAP PRE-INITIALIZE NODE TEST".
2. Press "1 - ARM ONE GAIGE INIT NODE TEST (SOLO / INERT)" once.
3. Continue into Gaige's map. Press "2 - CHECK INIT NODE RESULT (READ ONLY)".
4. Open Skills and inspect Little Big Trouble's first-row middle slot, between
   More Pep and Myelin. Report whether Deathtrap Overclock is visibly present
   and whether both original skills remain. DO NOT BUY THE NODE.
5. Return to MODS; press button 2 again, then
   "3 - CANCEL / RESTORE NATIVE ARRAYS (THEN RESTART)".
6. Close/restart BL2 to clear the engine-built player/UI cache. Do not re-arm or
   continue normal play in the test session. Tell Codex when done to read the log.

Expected [UVH-INITNODE] sequence: ARMED, PRE Gaige initialization,
SESSION role=standalone/listen_host local_players=1 roster_players=1
local_matches=True roster_matches=True,
PRE INSERT VERIFIED, RESULT native=True runtime_node_count=1
original_skills_present=True, Observers remaining=0. Then after CANCEL:
RESTORE result=True and NATIVE ARRAYS RESTORED. Data logs cannot establish UI
visibility; your visual report is required. An abort is a useful result: stop,
restart and share the log. Do not force writes using legacy insertion or purchases.

Arming loads no assets and modifies no definitions. The PRE callback requires:
NetMode matching the SDK's NM_Standalone or NM_ListenServer; exactly one local
ENGINE.GamePlayers entry with Actor==pc; exactly one WorldInfo.GRI.PRIArray entry
matching pc.PlayerReplicationInfo with Owner==pc; exact Gaige class, correct PlayerSkillTree
ownership, no pawn or existing branches, the exact Mechromancer SkillTreeDef,
the known native branch/layout relationship and six-tier shape, and pristine
first-row skills/occupancy. Missing/unexpected data aborts before shared writes.
Node effects/actions must be verifiably empty; MaxGrade=1, starting grade=0.
An existing candidate name is refused, never overwritten. No grade, point,
savefile, native save API or persistent gameplay effect is written by this mod.
The native function runs normally; neither its args nor return are overridden.

The snapshot is retained before array writes. Failed insertion attempts restore
native arrays; failed restores retain the snapshot for retry. Runtime verification
checks that the engine's Skills array includes the candidate and both original
skills. If not verified, native arrays are restored and restart is required.
Observers remove themselves after the matched initialization, even if another
mod blocked the native call. Arming is limited to one consumed Gaige attempt per
game session. Class/ownership/roster gates and native UI behavior still need an
actual v0.2.1 engine test. Roster availability at PRE is unverified; loading or
missing state fails closed. CHECK reports current session evidence after an abort,
without retrying insertion. POST rechecks solo evidence before cache verification.

ROLLBACK: button 3 disarms/removes observers and restores this mod's native arrays
if their contents still match its last writes. Foreign changes are not overwritten.
Disabling the mod performs the same cleanup. A partial/failed restore retains
the snapshot and reports failure; restart rather than continue playing.
IMPORTANT: restoring native arrays does not rewrite the engine-built player cache
or its skill indices. Restart BL2 after EVERY test to discard the cached prototype.
If anything reports a failed restore, exit without saving and restart. Keep the
backup; do not restore save files automatically or use this experiment in co-op.

Expected log tags: [UVH-LOAD], [UVH-LIVE], and [UVH-TRACE]. Snapshots report exact
asset availability, first-tier skills/occupancy, loaded Gaige trees, and tree
references. In Gaige's map they also inspect the local PlayerSkillTree, up to
three nested levels and 120 fields/entries. Native definition/type references and
controller/world backlinks are logged without following their graphs.
Optional Diagnostic buttons retain the read-only snapshot/trace workflow.
The trace discovers loaded initialization/refresh functions from SDK metadata;
it does not guess paths. Both Class:Function and dot-form paths are accepted;
raw discovered paths and scan counts are logged. It logs PRE/POST events with tree availability and
references, never blocks the function or changes its arguments/return value.
At most eight functions are observed and 24 events logged (two per phase per
function). Further callbacks are ignored until stopped. No trace starts on import.

Diagnostic observers/snapshots do not edit definitions, points, active effects or
saves, and do not load packages. STOP TREE INIT TRACE only stops diagnostics;
use CANCEL / RESTORE for the insertion experiment. Restart if observers remain.

Legacy insertion/check/removal buttons remain available for later testing.
Do not use legacy insertion during this run. It still modifies an
inert native skill at MAIN MENU only; never buy that node. Its removal button
restores original arrays; if restoration fails, exit without saving and restart.

The independently verified manual +15-second Deathtrap boost is preserved.
This version is locally tested ONLY until an actual v0.2.1 game log is reviewed.
