Ultimate Vault Hunters v0.2.6 - OVERCLOCK CORE UI TRACE.

NEXT TEST: observe normal skill-info/point-display navigation with core helpers
prioritized. Overclock remains INACTIVE. DO NOT BUY ANY SKILL.

v0.2.5 verified owned Overclock/MorePep/Myelin selection, unchanged sampled
points/ranks and restoration. Its ten-function cap omitted six core helpers.
v0.2.6 excludes artifact/equip candidates and prioritizes those loaded helpers
plus Init and Nav_Down/Left/Right inside the same ten-function cap.
74 local mocks pass. There is NO v0.2.6 game result yet. Eligibility/cost,
purchase, persistence and the node's automatic +15 seconds remain unverified.

INSTALL:
Close BL2. Replace only sdk_mods/UltimateVaultHunterDeathtrapBoost with this
ZIP's folder; keep one project mod and all PythonSDK/core mods. The folder
directly contains __init__.py, pyproject.toml, README.txt; no nested mod folder.
Use the already backed-up Gaige alone, network Offline, in a fresh BL2 process.

ONE TEST:
1. At MAIN MENU before Continue, confirm the exact MODS title:
   UVH v0.2.6 - OVERCLOCK CORE UI TRACE
   Press 1 - ARM ONE GAIGE INIT NODE TEST, then Continue.
   ARM after Continue refuses; it must run before the tree initializes.
2. In the map press 7 - START CORE SKILL UI TRACE.
3. Open Skills. Navigate to Deathtrap Overclock, More Pep, then Myelin using
   arrow keys/controller navigation. Pause about three seconds on each; hover
   them too if using a mouse. Do not click a skill or press upgrade/purchase
   controls or right-click. Finish promptly within 90 seconds.
4. Press 8 - STOP / REPORT UI TRACE + SNAPSHOT.
5. Press 3 - CANCEL / RESTORE NATIVE ARRAYS, then fully exit BL2.
6. Tell Codex "done" and leave BL2 closed until the final log is preserved.
   Restart before normal play to discard the engine-built prototype cache.

Use only 1,7,8,3. No 5/6, legacy insertion, old loading trace, manual boost,
respec, travel, co-op or point spending. If anything aborts or reaches a limit,
stop, cancel, exit and report it. Empty or partial traces are evidence.

OBSERVATION:
Discover at most 30000 loaded Function objects with exact Function class,
SkillTreeGFxObject outer and canonical WillowGame.SkillTreeGFxObject path.
Never invent paths from the priority list. Exclude artifact/equip names before
reflection. Prioritize PostNav, Navigate, HandleInputKey, UpdateInfoBox,
Flash_SetSkillPointProperties and Flash_SetSkillPointProperties_AS, then Init
and Nav_Down/Left/Right. extInitTree and other discovered navigation/refresh
methods are fallbacks when higher-priority functions are absent.
Log <=24 candidates, explicit SELECTED paths, <=8 raw fields per selected
function. Up to 10 functions/20 PRE and POST_UNCONDITIONAL observers.
POST_ANY may include calls blocked by another mod; it does not prove execution.
No args/ret reads, native invocation, overriding, package loads or observer
game-state writes. Signature metadata is not eligibility or cost.

Every callback rechecks current Gaige/controller/pawn/world/PRI/tree, both
sole-player rosters, exact inert patch/runtime registration and unchanged known
points/ranks/indices. Candidate grade stays zero. Require exact UI class and
WPCOwner==pc before reading separate CurrentSkill/CurrentSkill_Rollover.
Validate each definition's unique owned runtime entry/index. Unknown fields
are unavailable/unverified. UI points and target tier unlock are direct reads.
START/STOP inventory scans <=32 objects and prints <=4 owned views; absence
outside Skills is not proof of a missing live UI. No selection is forced.

Bounds stay 48 events, 2048 attempts, two copies per state, 90 seconds checked
on the NEXT callback, without a background timer. Always press STOP.
Stop/cancel/disable/error/change/limits clear capture before owned-hook removal.
Failed removals leave inert hooks for retry and prevent another trace.

EXPECTED LOG:
[UVH-INITNODE] PRE INSERT VERIFIED; one runtime node, both originals;
initialization observers remaining=0.
[UVH-UI] DISCOVERY/CANDIDATE/SELECTED/METADATA; START v0.2.6;
EVENT PRE/POST_ANY with current/rollover/UI points/tier unlock;
FINAL points/ranks unchanged_from_start=True; STOP remaining=0.
[UVH-NEWNODE] RESTORE result=True: MorePep/Myelin and True/False/True restored.

ROLLBACK / PRESERVED:
Button 3 restores only owned native array writes that still match; independent
changes are not overwritten and failed restores keep their snapshots.
This cannot clear caches, refund points, restore ranks or undo a save.
Restart after EVERY test. If restoration fails, exit without saving/restart.
All five tested v0.2.1-v0.2.5 ZIPs stay unchanged. The other 59 runtime functions
are AST-identical to v0.2.5; three functions only change version labels and only
_ui_candidates changes behavior. Insertion, solo guard, callbacks, cleanup
and the independently verified manual Deathtrap 60 -> 75 prototype remain
unchanged. The inert node does not apply that effect.
